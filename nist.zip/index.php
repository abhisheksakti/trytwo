 <!DOCTYPE html>
 <html>
    <head>
      <meta name="viewport" content="width=device-width">
      <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        	<link rel="stylesheet" href="home1heading.css" type="text/css" />

	<link rel="stylesheet" href="home1pageend.css" type="text/css" />
    <link rel="stylesheet" href="home1.css" type="text/css" />
    <link rel="icon" href="Arkangl300-Trash-Trash-Wood-Full.ico" type="image/x-icon"/>

       <title>ABHISHEK SAHU----MY FIRST WEB SITE </title>



    </head>


 <body>





  <div id="headingcontrol">
<div id="headingback">
<div id="heading" >

                <form action="login.php"  method="post" onsubmit="submitcheck()">
                   <div id="username">   <input  type="text" width="60" action="login.php" id="form" method="post"/></div>
                   <div id="password" >   <input type="password" action="login.php" id="form" method="post" /></div >
				   <div id="logincontrol"> <input  id="loginbutton" type="submit" value="LOGIN" /> </div>
	   	 	  </form>
     <div id="menu" >

	                  <div id="home" >
					                    <div id="downloadcontent1"><a href="home1.html" style="text-decoration:none;font-size:18px;color:white;">HOME </a></div>
					 </div>


                     <div id="news" >
					                    <div id="downloadcontent2"><a href="ready\news\news1.html" style="text-decoration:none;font-size:18px;color:white;">NEWS</a></div>
					 </div>



					<div id="downloads" >
					                    <div id="downloadcontent3"><a href="listt.html" style="text-decoration:none;font-size:18px;color:white;">DOWNLOADS </a></div>
					</div>



                   <div id="notice" >
					                    <div id="downloadcontent4"><a href="li.html" style="text-decoration:none;font-size:18px;color:white;">NOTICE </a></div>
					</div>



			   	<div id="search" >
					                    <div id="downloadcontent5"><a href="li.html" style="text-decoration:none;font-size:18px;color:white;">SEARCH </a></div>
					</div>
	</div>
<!--	<div id="logincontrol" >
     <input  id="loginbutton" type="submit" value="LOGIN" action="login.php"/>
    </div>
-->
</div>

   <div id="maintaincontrol">
   <h1 style="color:white;">Design and Maintaining by Abhishek Sahu</h1>
   </div>
   <div id="gif">
   </div>

</div>
</div>

<div id="homeback">
            <div id="put">

            </div>
        	<input style="position:absolute;left:110px;top:38px;"type="image" src="q.png" />
 <div id="answered">

<div id="container">
<table>
  <tr>
    <th>NEW TOPIC IS WHERE WE CAN SUBMIT FORM </th>
  </tr>


  <tr>
    <td>What is te cutoff:? </td>
  </tr>
<tr>
    <td>What is te cutoff:? </td>
  </tr>
  <tr>
    <td>What is te cutoff:? </td>
  </tr>
<tr>
    <td>What is te cutoff:? </td>
  </tr>
   <tr>
    <td>What is te cutoff:? </td>
  </tr>
<tr>
    <td>What is te cutoff:? </td>
  </tr>
   <tr>
    <td>What is te cutoff:? </td>
  </tr>
<tr>
    <td>What is te cutoff:? </td>
  </tr>
   <tr>
    <td>What is te cutoff:? </td>
  </tr>
<tr>
    <td>What is te cutoff:? </td>
  </tr>

</table>

 </div>
</div>



			<input style="position:absolute;left:100px;top:740px;"type="image" src="RA.png" />
			<div id="homegif">
			</div>
			<div id="online">


<div id="container">
<table>
  <tr>
    <th>ONLINE LIST FROM YOUR CLASSMATES </th>
	 <th </th>
  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>
  <tr>
    <td>Abhishek Sahu</td>
	<td>@</td>

  </tr>

</table>

 </div>

			</div>
			<input style="position:absolute;right:120px;top:72px;"type="image" src="O.png" />
			<div id="newdownloaded">





						<div id="container">
<table>
  <tr>
    <th>SUBJECT</th>
    <th>CATEGARORY</th>
    <th>TEACHER</th>
  </tr>
  <tr>
    <td>MATH</td>
    <td>assignment</td>
    <td>Dr.mihir hota</td>
  </tr>
   <tr>
    <td>MATH</td>
    <td>assignment</td>
    <td>Dr.mihir hota</td>
  </tr>
  <tr>
    <td>MATH</td>
    <td>assignment</td>
    <td>Dr.mihir hota</td>
  </tr>
  <tr>
    <td>MATH</td>
    <td>assignment</td>
    <td>Dr.mihir hota</td>
  </tr>
  <tr>
    <td>MATH</td>
    <td>assignment</td>
    <td>Dr.mihir hota</td>
  </tr>
  <tr>
    <td>MATH</td>
    <td>assignment</td>
    <td>Dr.mihir hota</td>
  </tr>

  </table>

 </div>

			</div>
			<input style="position:absolute;right:120px;top:760px;"type="image" src="S.png" />





       <div id="currenttopic">


<div id="container">
<table>
  <tr>
    <th>NEW TOPIC IS WHERE WE CAN SUBMIT FORM </th>
	   <th>    </th> <th>    </th>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
 <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
  <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr> <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr> <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr> <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr> <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr> <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr> <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr> <tr>
    <td>I think you should ask in lhc</td>
    <td></td>
    <td>Abhishek</td>
  </tr>
 </table>

 </div>
<div style="position:absolute;bottom:20px;left:8px;width:505px;background-color:pink;border:solid;
	border-bottom-style:solid;
	border-color:pink;
	border-spacing:9px;
	border-radius:2px;">
<form action="/action_page.php" ">
  Youyr Answer:
  <input type="text" name="firstname" value="Mickey"><br>
  <input type="submit" value="Submit">
</form>
</div>







		</div>
			<input style="position:absolute;left:558px;top:260px;"type="image" src="C.png" />

<div id="homeend">
  <div id="pageendback">
 	                       <div id="pageend1">

                                            <div id="content">
                                                   <div id="downloadslist">
					                                      <ul>
					                                       <h1 id="heaading" style="color:yellow">downloads</h1>
						                                   <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
														    <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															 <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															  <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															   <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
                                                           </ul>
                                                   </div>


										          <div id="notice">
					                                      <ul>
					                                       <h1 id="heaading" style="color:yellow">downloads</h1>
						                                   <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
														    <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															 <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															  <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															   <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
                                                           </ul>
                                                   </div>



										          <div id="news">
					                                      <ul>
					                                       <h1 id="heaading" style="color:yellow">downloads</h1>
						                                   <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
														    <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															 <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															  <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
															   <li id="downloadcontent"><a href="dd" style="text-decoration:none;color:white;">fisrt year</a> </li>
                                                           </ul>
                                                   </div>


										    </div>



									</div>
		   <div id="pageend2">
		        <div id="copyright1">
				   <h6  style="color:white;font-size:20px;"> use of this sight is goverend by our Terms and Conditions </h6>
				</div>
		        <div id="copyright2">
				   <h6  style="color:white;font-size:20px;"> copy right@ 2016-2020 </h6>
				</div>






		   </div>
	</div>
 </div>
<div>





 </body>
</html>
 <!--
   <div class="page"> <div class ="header"> <div class="logo"> <div class="cloud"></div> <div class="cloudlet"></div> <div class="curve1"></div> <div class="curve2"></div> <div class="curve3"></div> </div> <h1>HELLO WORLD</h1> <h2>You did it!</h2> <h3 class="blue">Your application is now running in the Cloud!</h3> <a id="header-link" href="http://jelastic.com/" target="_blank" class="powered-by"></a> <noscript> <h1 class="visible">HELLO WORLD</h1> <a href="http://jelastic.com/" target="_blank" class="visible powered-by"></a> </noscript> </div> <div class="share"> <div class="separator top"></div> <div class="join"></div> <div class="facebook-like"> <div id="fb-root"></div> <div class="fb-like" data-href="http://jelastic.com" data-send="false" data-layout="button_count" data-width="450" data-show-faces="false" data-font="trebuchet ms"></div> </div> <div class="social">  <a target="_blank" name="twitter" href="https://twitter.com/intent/tweet?original_referer=http%3A%2F%2Fjelastic.com%2F&source=tweetbutton&text=I've%20just%20deployed%20my%20first%20cloud%20app%20into%20Jelastic.%20Best%20PHP%20PaaS%20ever!&url=http%3A%2F%2Fjelastic.com%2F&via=jelastic" class="twitter"></a> <a target="_blank" name="facebook" href="http://www.facebook.com/sharer.php?u=https%3A%2F%2Fjelastic.com%2F&t=I've%20just%20deployed%20my%20first%20cloud%20app%20into%20Jelastic.%20Best%20PHP%20PaaS%20ever!" class="facebook"></a> <a target="_blank" name="google-plus" href="https://plus.google.com/share?url=http%3A%2F%2Fjelastic.com%2F&h1=en-US" class="google-plus"></a>  </div> <div class="arrow"></div> <div class="learn"></div> <div class="text"> <span class="tweet">Tweet<span class="blue">,</span></span> <span class="post">Post<span class="blue">,</span></span> <span class="share">Share</span> <span class="spread blue">&#151; Tell the World about Jelastic!</span> </div> <div class="separator bottom"></div> </div> <div class="links-block"> <div class="title">Useful links</div>  <div class="c1"> <ul class="links">  <li><a target="_blank" href="http://docs.jelastic.com/php-application-server-config">Make all necessary PHP Settings</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/php-extensions">Set different PHP Extensions</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/whole-project-deploying">Whole project deploying</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/ssh-access">SSH Access</a></li>  </ul> </div> <div class="c2"> <ul class="links">  <li><a target="_blank" href="http://docs.jelastic.com/php-git-svn">Deploy projects via GIT or SVN</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/app-packaging">Jelastic App Packaging</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/pricing-model">Pricing FAQ</a></li>  </ul> </div>  </div> <div class="footer"> &copy; <a id="footer-link" href="http://jelastic.com/" target="_blank">Jelastic Inc.</a>,
<?php echo date("Y") ?>
       All Rights Reserved. </div> </div> <script type="text/javascript"text/javascript" duris:nomerge=1>(function(e,a,f){var c,b=e.getElementsByTagName(a)[0];if(e.getElementById(f)){return}c=e.createElement(a);c.id=f;c.src="//connect.facebook.net/en_US/all.js#xfbml=1";b.parentNode.insertBefore(c,b)}(document,"script","facebook-jssdk"));var _gaq=_gaq||[];_gaq.push(["_setAccount","UA-24049059-10"]);_gaq.push(["_setDomainName","example.com"]);_gaq.push(["_setAllowLinker",true]);_gaq.push(["_trackPageview"]);(function(){var b=document.createElement("script");b.type="text/javascript";b.async=true;b.src=("https:"==document.location.protocol?"https://ssl":"http://www")+".google-analytics.com/ga.js";var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(b,a)})();</script> <script src="public/optimum/js/f0ec53c40f3f25833ddf8b6ef147fe8f.out.js" type="text/javascript"></script>
-->