 <!DOCTYPE html>
 <html>
    <head>
      <meta name="viewport" content="width=device-width">
      <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">




       <title>ABHISHEK SAHU----MY FIRST WEB SITE </title>
       <link href="public/optimum/css/f1902cfa8c412a28ee0fe637a92a072d.out.css" rel="stylesheet" type="text/css"/>
       <link href="public/optimum/css/85fccb94f3e2f5620210f2c1d60ce927.addon.b64.css" rel="stylesheet" type="text/css"/>
       <link href="mystyle.css" rel="stylesheet" type="text/css"/>

                 <style>
                    a:link
                         {
                         color:black;
                         }
                         a:visited
                         {
                         color:green;
                         }
                         a:hover
                         {
                         color:blue;
                         }
           </style>

    </head>


 <body>
  <h6 style=" background-image:url('ff.png');" >  welcome everyone to my web site</h6>
       </hr>
       <h1 id="design" style="color:purple;">Design and Developed by ABHISHEK SAHU</h1>
          <input type="image" src="abc.jpg" height=300px  >
        <div>
        <h1 id="a" >1.about the developer</h1>
        <a  href="developer.pdf">click here </a>
        <h1 id="b" >2.downloadlist</h1><td>
        <a href="listt.html">click here </a>
      </div>
      </br>
       </br>
       </br>
       </br>
       </br>
       </br>
       </br>
       </br></br>
       <h1 id="copyright" >@copyright 2016-2020 </h1>

 </body>
</html>
 <!--
   <div class="page"> <div class ="header"> <div class="logo"> <div class="cloud"></div> <div class="cloudlet"></div> <div class="curve1"></div> <div class="curve2"></div> <div class="curve3"></div> </div> <h1>HELLO WORLD</h1> <h2>You did it!</h2> <h3 class="blue">Your application is now running in the Cloud!</h3> <a id="header-link" href="http://jelastic.com/" target="_blank" class="powered-by"></a> <noscript> <h1 class="visible">HELLO WORLD</h1> <a href="http://jelastic.com/" target="_blank" class="visible powered-by"></a> </noscript> </div> <div class="share"> <div class="separator top"></div> <div class="join"></div> <div class="facebook-like"> <div id="fb-root"></div> <div class="fb-like" data-href="http://jelastic.com" data-send="false" data-layout="button_count" data-width="450" data-show-faces="false" data-font="trebuchet ms"></div> </div> <div class="social">  <a target="_blank" name="twitter" href="https://twitter.com/intent/tweet?original_referer=http%3A%2F%2Fjelastic.com%2F&source=tweetbutton&text=I've%20just%20deployed%20my%20first%20cloud%20app%20into%20Jelastic.%20Best%20PHP%20PaaS%20ever!&url=http%3A%2F%2Fjelastic.com%2F&via=jelastic" class="twitter"></a> <a target="_blank" name="facebook" href="http://www.facebook.com/sharer.php?u=https%3A%2F%2Fjelastic.com%2F&t=I've%20just%20deployed%20my%20first%20cloud%20app%20into%20Jelastic.%20Best%20PHP%20PaaS%20ever!" class="facebook"></a> <a target="_blank" name="google-plus" href="https://plus.google.com/share?url=http%3A%2F%2Fjelastic.com%2F&h1=en-US" class="google-plus"></a>  </div> <div class="arrow"></div> <div class="learn"></div> <div class="text"> <span class="tweet">Tweet<span class="blue">,</span></span> <span class="post">Post<span class="blue">,</span></span> <span class="share">Share</span> <span class="spread blue">&#151; Tell the World about Jelastic!</span> </div> <div class="separator bottom"></div> </div> <div class="links-block"> <div class="title">Useful links</div>  <div class="c1"> <ul class="links">  <li><a target="_blank" href="http://docs.jelastic.com/php-application-server-config">Make all necessary PHP Settings</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/php-extensions">Set different PHP Extensions</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/whole-project-deploying">Whole project deploying</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/ssh-access">SSH Access</a></li>  </ul> </div> <div class="c2"> <ul class="links">  <li><a target="_blank" href="http://docs.jelastic.com/php-git-svn">Deploy projects via GIT or SVN</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/app-packaging">Jelastic App Packaging</a></li>  <li><a target="_blank" href="http://docs.jelastic.com/pricing-model">Pricing FAQ</a></li>  </ul> </div>  </div> <div class="footer"> &copy; <a id="footer-link" href="http://jelastic.com/" target="_blank">Jelastic Inc.</a>,
<?php echo date("Y") ?>
       All Rights Reserved. </div> </div> <script type="text/javascript"text/javascript" duris:nomerge=1>(function(e,a,f){var c,b=e.getElementsByTagName(a)[0];if(e.getElementById(f)){return}c=e.createElement(a);c.id=f;c.src="//connect.facebook.net/en_US/all.js#xfbml=1";b.parentNode.insertBefore(c,b)}(document,"script","facebook-jssdk"));var _gaq=_gaq||[];_gaq.push(["_setAccount","UA-24049059-10"]);_gaq.push(["_setDomainName","example.com"]);_gaq.push(["_setAllowLinker",true]);_gaq.push(["_trackPageview"]);(function(){var b=document.createElement("script");b.type="text/javascript";b.async=true;b.src=("https:"==document.location.protocol?"https://ssl":"http://www")+".google-analytics.com/ga.js";var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(b,a)})();</script> <script src="public/optimum/js/f0ec53c40f3f25833ddf8b6ef147fe8f.out.js" type="text/javascript"></script>
-->