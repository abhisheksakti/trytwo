function submitcheck()
{
	var user=document.getElementById("username");
	var pass=document.getElementById("password");
	if(username.value!="abhishek" && password.value!="sahu")
	   alert(user);
    else
    {
		alert("right");
	  window.location("http//google.com");
     }
}